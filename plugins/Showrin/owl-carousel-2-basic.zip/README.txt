A Pen created at CodePen.io. You can find this one at https://codepen.io/Showrin/pen/mKrBBp.

 Added fix for blank or flashing items in carousel.