A Pen created at CodePen.io. You can find this one at https://codepen.io/jackoliver/pen/qVbQqW.

 Useful for startup landing pages where you need to display brand partners and other cool logos or whatever. 

Enjoy. :)